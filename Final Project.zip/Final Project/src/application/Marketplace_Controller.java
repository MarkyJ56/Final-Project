package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class Marketplace_Controller {
;
	@FXML
	Label mainCurrentLBL, balanceCheckerLBL; // Current Balance label and label that checks balance and displays output
	
	Double mainCurrentBalance = 0.00; // Current Balance used for Main operations
	String[] purchasedGames = {"", "", "", "", ""};
	
	public void displayfromBalance(Double currentBalance, String[] balGames) { // Displays the current balance from balance scene
		mainCurrentLBL.setText(String.format("$%.2f", currentBalance));
		mainCurrentBalance = currentBalance;
		purchasedGames = balGames;
	}
	public void displayfromLibrary(Double libCurrentBalance, String[] libGames) { // Displays the current balance from library scene
		mainCurrentLBL.setText(String.format("$%.2f", libCurrentBalance));
		mainCurrentBalance = libCurrentBalance;
		
		purchasedGames = libGames;
	}
	@FXML
	private Button LibraryBTN, BalanceBTN; // Scene switch Buttons
	@FXML
	private Button sevBTN, csgoBTN, falloutBTN, haloBTN, nwBTN; // Purchase buttons for games
	
	@FXML
	public void switchScenes(ActionEvent event) throws IOException { // Event to switch scenes
		Stage stage = null;
		Parent root = null;
		
		if (event.getSource() == LibraryBTN) { // Switches scene to Library
			stage = (Stage) LibraryBTN.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Library.fxml"));
            // Loader to send current balance to Library
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Library.fxml"));
	        root = loader.load();
	        Library_Controller library = loader.getController();
	        library.displayfromMain(mainCurrentBalance, purchasedGames);
		}
		else if (event.getSource() == BalanceBTN) { // Switches scene to Balance
			stage = (Stage) BalanceBTN.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("AddBalance.fxml"));
            // Loader to send current balance to Balance
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddBalance.fxml"));
	        root = loader.load();
	        Balance_Controller balance = loader.getController();
	        balance.displayfromMain(mainCurrentBalance, purchasedGames);
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void purchaseGame(ActionEvent event) throws IOException{
		if (event.getSource() == sevBTN) { // Checks if balance is valid for 7 days
			if (mainCurrentBalance > 24.99) {
			sevBTN.setText("Purchased");
			sevBTN.setDisable(true);
			mainCurrentBalance -= 24.99;
			mainCurrentLBL.setText(String.format("$%.2f", mainCurrentBalance));
			balanceCheckerLBL.setText("Game Purchased");
			purchasedGames[0] = "7 Days To Die"; 
			}
			else {
				balanceCheckerLBL.setText("Insufficient Funds");
			}
		}
		else if (event.getSource() == csgoBTN) { // Checks if balance is valid for csgo
			if (mainCurrentBalance > 14.99) {
				csgoBTN.setText("Purchased");
				csgoBTN.setDisable(true);
				mainCurrentBalance -= 14.99;
				mainCurrentLBL.setText(String.format("$%.2f", mainCurrentBalance));
				balanceCheckerLBL.setText("Game Purchased");
				purchasedGames[1] = "Counter-Strike: Global Offensive";
			}
			else {
					balanceCheckerLBL.setText("Insufficient Funds");
			}
		}
		else if (event.getSource() == falloutBTN) { // Checks if balance is valid for fallout
			if (mainCurrentBalance > 39.99) {
				falloutBTN.setText("Purchased");
				falloutBTN.setDisable(true);
				mainCurrentBalance -= 39.99;
				mainCurrentLBL.setText(String.format("$%.2f", mainCurrentBalance));
				balanceCheckerLBL.setText("Game Purchased");
				purchasedGames[2] = "Fallout 76";
				}
			else {
					balanceCheckerLBL.setText("Insufficient Funds");
				}
		}
		else if (event.getSource() == haloBTN) { // Gets halo
			haloBTN.setText("Purchased");
			haloBTN.setDisable(true);
			purchasedGames[3] = "Halo Infinite";
		}
		else if (event.getSource() == nwBTN) { // Checks if balance is valid for new world
			if (mainCurrentBalance > 39.99) {
				nwBTN.setText("Purchased");
				nwBTN.setDisable(true);
				mainCurrentBalance -= 39.99;
				mainCurrentLBL.setText(String.format("$%.2f", mainCurrentBalance));
				balanceCheckerLBL.setText("Game Purchased");
				purchasedGames[4] = "New World";
				}
			else {
					balanceCheckerLBL.setText("Insufficient Funds");
				}
		}
	}
	
}

