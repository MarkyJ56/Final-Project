package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Library_Controller implements Initializable{

	@FXML
	Label libCurrentLBL, displayTitleLBL, displaySizeLBL, displayDescriptionLBL, displayDateLBL; // Label for current balance in Library, and labels for game description
	@FXML
	private ListView<String> libraryList;
	String[] libGames;
	String currentGame;
	
	Double libCurrentBalance = 0.00; // Current Balance in the Library scene
	
	public void displayfromBalance(Double currentBalance, String[] balGames) { // Displays current balance from Balance scene
		libCurrentLBL.setText(String.format("$%.2f", currentBalance));
		libCurrentBalance = currentBalance;
		
		for(int i = 0; i < 5; i++) {
			if (balGames[i] != "") {
				libraryList.getItems().add(balGames[i]);
	}
		}
		libGames = balGames;
	}
	public void displayfromMain(Double mainCurrentBalance, String[] purchasedGames) { // Displays current balance from Main scene
		libCurrentLBL.setText(String.format("$%.2f", mainCurrentBalance));
		libCurrentBalance = mainCurrentBalance;
		
		for(int i = 0; i < 5; i++) {
			if (purchasedGames[i] != "") {
				libraryList.getItems().add(purchasedGames[i]);
	}
		}
		libGames = purchasedGames;
	}
	
	@FXML
	private Button MarketplaceBTN, BalanceBTN; // Switch scenes buttons
	
	@FXML
	public void switchScenes(ActionEvent event) throws IOException { // Event to switch scenes
		Stage stage = null;
		Parent root = null;
		
		if (event.getSource() == MarketplaceBTN) { // Switches to Main
			stage = (Stage) MarketplaceBTN.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Main.fxml"));
         // Loader to send current balance to Main
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
	        root = loader.load();
	        Marketplace_Controller marketplace = loader.getController();
	        marketplace.displayfromBalance(libCurrentBalance, libGames);
            
		}
		else if (event.getSource() == BalanceBTN) { // Switches to Balance
			stage = (Stage) BalanceBTN.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("AddBalance.fxml"));
            // Loader to send current balance to Balance
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddBalance.fxml"));
	        root = loader.load();
	        Balance_Controller balance = loader.getController();
	        balance.displayfromLibrary(libCurrentBalance, libGames);
            

		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		libraryList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {

			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {

				currentGame = libraryList.getSelectionModel().getSelectedItem();
				if (currentGame == "7 Days To Die") {
					displayTitleLBL.setText(currentGame);
					displayDescriptionLBL.setText("Multiplayer Zombie Survival Game.");
					displaySizeLBL.setText("12 GB");
					displayDateLBL.setText("December 13, 2013");
				}
				else if (currentGame == "Fallout 76") {
					displayTitleLBL.setText(currentGame);
					displayDescriptionLBL.setText("Multiplayer Open-World MMO.");
					displaySizeLBL.setText("80 GB");
					displayDateLBL.setText("April 14, 2020");
				}
				else if (currentGame == "Halo Infinite") {
					displayTitleLBL.setText(currentGame);
					displayDescriptionLBL.setText("First Person Battle Arena Shooter.");
					displaySizeLBL.setText("50 GB");
					displayDateLBL.setText("November 15, 2021");
				}
				else if (currentGame == "Counter-Strike: Global Offensive") {
					displayTitleLBL.setText(currentGame);
					displayDescriptionLBL.setText("Tactical First Person Shooter.");
					displaySizeLBL.setText("15 GB");
					displayDateLBL.setText("August 21, 2012");
				}
				else if (currentGame == "New World") {
					displayTitleLBL.setText(currentGame);
					displayDescriptionLBL.setText("Multiplayer Open-World Fantasy MMO.");
					displaySizeLBL.setText("50 GB");
					displayDateLBL.setText("September 28, 2021");
				}
				
			}

		}); 
	}
}


