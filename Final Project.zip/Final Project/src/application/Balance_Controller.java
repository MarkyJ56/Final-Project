package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Balance_Controller {
	
	@FXML
	Label ErrorLBL, currentBalanceLBL; // Label for input error and current balance
	
	
	@FXML
	private TextField addedBalanceTXT; // User input text field to specify amount of balance to add
	@FXML
	private Button addBalanceBTN, LibraryBTN, MarketplaceBTN; // Buttons to switch scenes and add balance
	double additionalBalance; // amount entered by user to add to balance
	double currentBalance = 0.00; // Current Balance for Balance Scene
	String[] balGames;

	public void displayfromMain(Double mainCurrentBalance, String[] purchasedGames) { // Displays current balance from Main scene
		currentBalanceLBL.setText(String.format("$%.2f", mainCurrentBalance));
		currentBalance = mainCurrentBalance;
		balGames = purchasedGames;
	}
	public void displayfromLibrary(Double libCurrentBalance, String[] libGames) { // Displays the current balance from library scene
		currentBalanceLBL.setText(String.format("$%.2f", libCurrentBalance));
		currentBalance = libCurrentBalance;
		balGames = libGames;
	}
	
	@FXML
	public void switchScenes(ActionEvent event) throws IOException { // Event ot switch scenes
		Stage stage = null;
		Parent root = null;
		
		if (event.getSource() == LibraryBTN) { // Switches to Library Scene
			stage = (Stage) LibraryBTN.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Library.fxml"));
            // Loader to send current balance to Library
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Library.fxml"));
	        root = loader.load();
	        Library_Controller library = loader.getController();
	        library.displayfromBalance(currentBalance, balGames);
		}
		else if (event.getSource() == MarketplaceBTN) { // Switches to Main Scene
			stage = (Stage) MarketplaceBTN.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Main.fxml"));
            // Loader to send current balance to Main
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
	        root = loader.load();
	        Marketplace_Controller marketplace = loader.getController();
	        marketplace.displayfromBalance(currentBalance, balGames);
		}
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void additionBalance(ActionEvent event) { // Event to add additional balance to current balance
		try {
		additionalBalance = Double.parseDouble(addedBalanceTXT.getText());
		if (additionalBalance > 0) {
			currentBalance += additionalBalance;
			currentBalanceLBL.setText(String.format("$%.2f", currentBalance));
			ErrorLBL.setText("Balance has been added!"); 
			
		}
		else {
			ErrorLBL.setText("Enter an amount above 0.");
		}
		
		}
		catch (NumberFormatException e){
			ErrorLBL.setText("Enter numbers only.");
		}
		catch (Exception e) {
			ErrorLBL.setText("Error");
		}
	}

}
